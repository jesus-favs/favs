class Ping < ActiveRecord::Base
end
