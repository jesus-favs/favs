module PingHelper
end
