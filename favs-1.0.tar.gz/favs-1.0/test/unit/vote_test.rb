require File.dirname(__FILE__) + '/../test_helper'

class VoteTest < Test::Unit::TestCase
  fixtures :votes

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
