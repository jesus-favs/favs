# es-CAT lang file
Locale.set('es-CAT')
Locale.set_translation 'read more',               'Segueix llegint'
Locale.set_translation 'Feevy is a free service', 'Feevy es un servei lliure i gratuït'
Locale.set_translation 'Get yours',               'Fes el teu'
