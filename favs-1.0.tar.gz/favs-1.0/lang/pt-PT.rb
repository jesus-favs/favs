# pt-PT lang file
Locale.set('pt-PT')
Locale.set_translation 'read more',               'leia mais'
Locale.set_translation 'Feevy is a free service', 'Feevy é um serviço livre'
Locale.set_translation 'Get yours',               'tenha também o seu!'