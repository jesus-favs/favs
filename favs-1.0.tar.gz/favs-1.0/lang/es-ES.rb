# es-ES lang file
Locale.set('es-ES')
Locale.set_translation 'read more',               'Sigue leyendo'
Locale.set_translation 'Feevy is a free service', 'Feevy es libre y gratuito'
Locale.set_translation 'Get yours',               'Hazte uno'
