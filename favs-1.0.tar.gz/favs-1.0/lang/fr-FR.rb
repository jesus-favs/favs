# fr-FR lang file
Locale.set('fr-FR')
Locale.set_translation 'read more',               'Lire plus'
Locale.set_translation 'Feevy is a free service', 'Feevy est un service libre et gratuit'
Locale.set_translation 'Get yours',               'Crée le tiens'
