# eo-EO lang file
Locale.set('eo-EO')
Locale.set_translation 'read more',               'Legu pli'
Locale.set_translation 'Feevy is a free service', 'Feevy estas senpaga servo'
Locale.set_translation 'Get yours',               'Akiru vian'
