# es-AR lang file
Locale.set('es-AR')
Locale.set_translation 'read more',               'Seguí leyendo'
Locale.set_translation 'Feevy is a free service', 'Feevy es libre y gratuito'
Locale.set_translation 'Get yours',               'Hacé el tuyo'
