# es-BA lang file
Locale.set('es-BA')
Locale.set_translation 'read more',               'Gehiago irakurri'
Locale.set_translation 'Feevy is a free service', 'Feevy aske eta doan da.'
Locale.set_translation 'Get yours',               'Zurea egin'
